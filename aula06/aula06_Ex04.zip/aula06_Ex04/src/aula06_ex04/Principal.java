/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aula06_ex04;

/**
 *
 * @author unifybarros
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Morcego morcego = new Morcego("Bruce");
        
        // Testando os métodos
        System.out.println("Nome: " + morcego.nome);
        morcego.andar();
        morcego.voar();
    }
}
    
