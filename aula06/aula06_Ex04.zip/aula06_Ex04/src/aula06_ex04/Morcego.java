/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula06_ex04;

/**
 *
 * @author unifybarros
 */
class Morcego extends Animal implements IWalkable, IFlyable {
    public Morcego(String nome) {
        super(nome);
    }

    @Override
    public void andar() {
        System.out.println(nome + " está andando.");
    }

    @Override
    public void voar() {
        System.out.println(nome + " está voando.");
    }
}