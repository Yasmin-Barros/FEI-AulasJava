/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula06_ex03;

/**
 *
 * @author unifybarros
 */
public class Professor extends Agente {
    private String escola;
    
    public Professor(String nome, String profissao, String escola) {
        super(nome, profissao);
        this.escola = escola;
    }
    
    @Override
    public void apresentacao() {
        System.out.println("Sou " + nome + ", professor na escola " + escola);
    }
}