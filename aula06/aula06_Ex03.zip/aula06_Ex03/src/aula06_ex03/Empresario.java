/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula06_ex03;

/**
 *
 * @author unifybarros
 */
public class Empresario extends Agente {
    private String empresa;
    
    public Empresario(String nome, String profissao, String empresa) {
        super(nome, profissao);
        this.empresa = empresa;
    }
    
    @Override
    public void apresentacao() {
        System.out.println("Sou " + nome + ", um empresario dono da empresa " + empresa);
    }
}
    
