/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aula06_ex03;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author unifybarros
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Agente> agentes = new ArrayList<>();  
        while (true) {
            System.out.println("1. Criar Empresario");
            System.out.println("2. Criar Professor");
            System.out.println("3. Criar Advogado");
            System.out.println("4. Listar Agentes");
            System.out.println("5. Ativar modo agente");
            System.out.println("6. Sair");
            int opcao = scanner.nextInt();
            scanner.nextLine();
            
            if (opcao == 6) break;
            
            if (opcao >= 1 && opcao <= 3) {
                System.out.print("Nome: ");
                String nome = scanner.nextLine();
                System.out.print("Profissão: ");
                String profissao = scanner.nextLine();
                
                if (opcao == 1) {
                    System.out.print("Empresa: ");
                    String empresa = scanner.nextLine();
                    agentes.add(new Empresario(nome, profissao, empresa));
                } else if (opcao == 2) {
                    System.out.print("Escola: ");
                    String escola = scanner.nextLine();
                    agentes.add(new Professor(nome, profissao, escola));
                } else if (opcao == 3) {
                    System.out.print("OAB: ");
                    String OAB = scanner.nextLine();
                    agentes.add(new Advogado(nome, profissao, OAB));
                }
            } else if (opcao == 4) {
                for (Agente agente : agentes) {
                    System.out.println(agente);
                    }
            } else if (opcao == 5) {
                System.out.print("Escolha o índice do agente: ");
                int index = scanner.nextInt();
                if (index >= 0 && index < agentes.size()) { //&& é AND
                    agentes.get(index).modo_agente_on();
                } else {
                    System.out.println("Índice inválido");
                }
            }
        }
        scanner.close();
    }
}
